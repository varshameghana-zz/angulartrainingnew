angular.module('myapp')
    .component('productdetails', {
        templateUrl: 'components/productdetails/productdetails.component.html'
    });