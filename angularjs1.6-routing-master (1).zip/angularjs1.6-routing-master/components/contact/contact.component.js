angular.module('myapp')
    .component('contact', {
        templateUrl: 'components/contact/contact.component.html'
    });